package com.example.spring.demo.service.employeservice;


import com.example.spring.demo.entity.Request;

import java.util.List;

public interface EmployeeService {

    List<Request> retrieveAllRequest();

}
